package mvcPack;

public class ModelExmp 
{
	String name,pd;
	public void accept(String us, String pw)
	{
		name = us;
		pd = pw;
	}
	public boolean loginValidation()
	{
		if(name.equals("rahul") && pd.equals("1234"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
